function buyer(){
    window.location.href = 'https://therealestate-710385233.development.catalystserverless.com/app/ZylerApp/Buyer/buyer.html?isRedirectFromCrm=false&PropName=abc';
}

function seller(){
    window.location.href = 'https://therealestate-710385233.development.catalystserverless.com/app/ZylerApp/SellerContact/seller.html';
}